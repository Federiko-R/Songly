document.addEventListener("DOMContentLoaded", () => {
      const async = document.createElement('script'); async.async = true;
      const defer = document.createElement('script'); defer.defer = true;
      if (window.matchMedia("(orientation: portrait)").matches) {
            async.src = '/assets/js/mobile/async.js';
            defer.src = '/assets/js/mobile/defer.js'
      } else {
            async.src = '/assets/js/desktop/async.js';
            defer.src = '/assets/js/desktop/defer.js';
      }
      document.querySelector('head').appendChild(async);
      document.querySelector('head').appendChild(defer);
});