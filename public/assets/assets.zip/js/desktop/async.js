// Fade Header
    const header = document.getElementById('header');
    const drop = document.getElementById('drop');
    const pool = document.getElementById('pool');
    const eye = document.getElementById('eye');
    droped = () => {pool.classList.toggle('invisiblePool');
        if (pool.classList.contains('invisiblePool'))
        {eye.classList.toggle('fade'); 
        header.style.pointerEvents = 'none'
        setTimeout(EyeOff, 300)} 
        else 
        {eye.classList.toggle("fade"); 
        header.style.pointerEvents = 'all'
        setTimeout(EyeOn, 300)}};
    EyeOn = () => {eye.src = "/assets/icons/eye.svg"; eye.classList.toggle("fade")};
    EyeOff = () => {eye.src = "/assets/icons/eye-off.svg"; eye.classList.toggle("fade")};
    drop.addEventListener('click', droped);
    
// Open header 
    const btns = document.querySelectorAll('header i');
    for (var i of btns) i.addEventListener('mouseover', (e, data = e.target.dataset.image) => pool.style.backgroundImage = `url(/assets/chords/${data}.png), linear-gradient(to right, var(--orange), var(--red), var(--magenta))`);
    for (var i of btns) i.addEventListener('mouseout', () => pool.style.backgroundImage = 'linear-gradient(to right, var(--orange), var(--red), var(--magenta))');
        