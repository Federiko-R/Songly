// Menu
    const nav = document.querySelector('nav');
    const menu = document.querySelector('button p');
    const menuIcon = document.querySelector('button svg');
    const menuPath = document.querySelector('button svg path');
    function openMenu() {
        nav.classList.add('about');
        menuPath.setAttribute('d', 'M2 2 L6 6 M2 6 L6 2 M2 2 L6 6');
        document.body.style.overflow = 'hidden';
    }
    function closeMenu() {
        nav.classList.remove('about');
        menuPath.setAttribute('d', 'M1 2 L7 2 M1 4 L7 4 M1 6 L7 6');
        document.body.style.overflow = 'initial';
    }
    menu.addEventListener('click', openMenu);
    menuIcon.addEventListener('click', closeMenu)

// Strum
    const h4 = document.getElementsByTagName('h4')
    const S1 = document.getElementById('first-strum').innerHTML
    const S2 = document.getElementById('second-strum').innerHTML
    const S3 = document.getElementById('third-strum').innerHTML
    const S4 = document.getElementById('fourth-strum').innerHTML
    /* for (var i of h4) i.addEventListener('mouseover', (e) => {
        e.target.style.color = 'transparent';
        timeout = setTimeout(() => {
            e.target.innerHTML = e.target.dataset.strum;
            e.target.style.color = 'white';
            clearTimeout(timeout)
        }, 300);
    }); */
    for (var x of h4) x.addEventListener('mouseover', (event) => {
        if (event.target.classList.contains('first')) {
            event.target.style.color = 'transparent';
            timeout = setTimeout(() => { 
                event.target.innerHTML = S1; 
                event.target.style.color = 'white';
            }, 300);
        }
        else if (event.target.classList.contains('second')) {
            event.target.style.color = 'transparent';
            timeout = setTimeout(function () {
                event.target.innerHTML = S2;
                event.target.style.color = 'white'
            }, 300);
        }
        else if (event.target.classList.contains('third')) {
            event.target.style.color = 'transparent';
            timeout = setTimeout(function () {
                event.target.innerHTML = S3;
                event.target.style.color = 'white'
            }, 300);
        }
        else if (event.target.classList.contains('fourth')) {
            event.target.style.color = 'transparent';
            timeout = setTimeout(function () {
                event.target.innerHTML = S4;
                event.target.style.color = 'white'
            }, 300);
        }
    });
    for (var x of h4) x.addEventListener('mouseout', (event) => {
        event.target.style.color = 'transparent';
        clearTimeout(timeout);
        setTimeout(() => {
            event.target.innerText = 'Rasguido';
            event.target.style.color = 'white';
        }, 300)
    })